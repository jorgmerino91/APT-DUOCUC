import { supabase, SUPABASE_URL, SUPABASE_ANON } from "./supabaseClient";

async function invokeWithSdk(survey) {
  // ¡sin headers! el SDK los agrega
  const { data, error } = await supabase.functions.invoke("generate-plan", {
    body: { survey },
  });

  if (error) {
    // intenta leer status/text si tu SDK lo expone
    let status, bodyText;
    try {
      status = error?.context?.response?.status;
      bodyText = await error?.context?.response?.text?.();
    } catch (_) {}
    console.warn("[Edge invoke][SDK] status:", status, "body:", bodyText);
    throw new Error(bodyText || error.message || "Edge Function error (SDK)");
  }

  if (!data?.ok || !data?.plan)
    throw new Error("Respuesta inválida del servidor (SDK)");
  return data.plan;
}

async function invokeWithFetch(survey) {
  const endpoint = `${SUPABASE_URL}/functions/v1/generate-plan`;
  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${SUPABASE_ANON}`,
      apikey: SUPABASE_ANON,
    },
    body: JSON.stringify({ survey }),
  });

  const data = await res.json().catch(() => ({}));
  console.log("[Edge invoke][fetch] http:", res.status, "ok:", data?.ok);

  if (!res.ok) throw new Error(data?.error || `HTTP ${res.status} (fetch)`);
  if (!data?.ok || !data?.plan)
    throw new Error("Respuesta inválida del servidor (fetch)");
  return data.plan;
}

export async function generatePlan({ survey }) {
  if (!survey) throw new Error("Falta el objeto survey");

  console.log("[planService] supabase OK?", typeof supabase === "object");
  console.log(
    "[planService] has functions.invoke?",
    typeof supabase?.functions?.invoke
  );

  // 1) intenta SDK sin headers
  try {
    return await invokeWithSdk(survey);
  } catch (e) {
    console.warn(
      "[SDK invoke falló, probando fetch]:",
      String(e?.message ?? e)
    );
    // 2) fallback por fetch directo
    return await invokeWithFetch(survey);
  }
}

export default { generatePlan };

/**
 * Guarda un plan en la tabla training_plans.
 * @param {object} args
 * @param {object} args.plan - JSON final normalizado que muestras en PlanScreen
 * @param {object} args.survey - encuesta enviada (incluye weeks, days, etc.)
 * @param {string} [args.title] - título visible (opcional)
 * @param {string} [args.userChange] - texto de modificaciones (opcional)
 * @returns {Promise<object>} fila insertada
 */
export async function savePlan({ plan, survey, title, userChange }) {
  console.log("[savePlan] start");
  // Loguea estado de auth
  const { data: sessionData, error: sessErr } =
    await supabase.auth.getSession();
  if (sessErr) console.warn("[savePlan] getSession error:", sessErr);
  console.log("[savePlan] hasSession:", !!sessionData?.session);

  const {
    data: { user },
    error: userErr,
  } = await supabase.auth.getUser();
  if (userErr) {
    console.warn("[savePlan] getUser error:", userErr);
    throw userErr;
  }
  console.log("[savePlan] userId:", user?.id || null);

  if (!user) {
    // Mensaje claro para la UI
    throw new Error(
      "Auth session missing: debes iniciar sesión para guardar el plan."
    );
  }

  const payload = {
    user_id: user.id,
    title: title || `Plan ${new Date().toLocaleDateString()}`,
    overview: plan?.overview ?? null,
    weeks_count: plan?.meta?.planDurationWeeks ?? null,
    days_per_week: plan?.meta?.daysPerWeek ?? null,
    avg_minutes_session: plan?.meta?.avgMinutesSession ?? null,
    model: plan?.meta?.model ?? null,
    user_change: userChange || null,
    survey,
    plan,
  };

  // Evita loggear JSON gigante: muestra solo cabecera
  const debugHeader = { ...payload, survey: "[json]", plan: "[json]" };
  console.log("[savePlan] payload hdr:", debugHeader);

  const { data, error } = await supabase
    .from("training_plans")
    .insert(payload)
    .select()
    .single();

  if (error) {
    console.warn("[savePlan] insert error:", error);
    throw error;
  }

  console.log("[savePlan] inserted id:", data?.id);
  return data;
}

// ======= LECTURAS (historial) =======

/**
 * Obtiene el usuario actual (requiere sesión). Lanza si no hay sesión.
 */
async function getCurrentUserOrThrow() {
  const { data: sessionData, error: sessErr } =
    await supabase.auth.getSession();
  if (sessErr) console.warn("[plans:list] getSession error:", sessErr);
  const {
    data: { user },
    error: userErr,
  } = await supabase.auth.getUser();
  if (userErr) throw userErr;
  if (!user)
    throw new Error("No hay sesión: inicia sesión para ver tus planes.");
  return user;
}

/**
 * Devuelve el plan activo del usuario (o null si no hay).
 */
export async function getActivePlan() {
  const user = await getCurrentUserOrThrow();
  const { data, error } = await supabase
    .from("training_plans")
    .select("*")
    .eq("user_id", user.id)
    .eq("is_active", true)
    .order("active_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw error;
  return data || null;
}

/**
 * Lista planes inactivos/historial del usuario, ordenados del más nuevo al más antiguo.
 * @param {{limit?: number}} opts
 */
export async function listInactivePlans(opts = {}) {
  const user = await getCurrentUserOrThrow();
  const { limit = 100 } = opts;
  const { data, error } = await supabase
    .from("training_plans")
    .select("*")
    .eq("user_id", user.id)
    .eq("is_active", false)
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data || [];
}

/**
 * Obtiene un plan por id (para abrir detalle).
 */
export async function getPlanById(id) {
  const user = await getCurrentUserOrThrow();
  const { data, error } = await supabase
    .from("training_plans")
    .select("*")
    .eq("user_id", user.id)
    .eq("id", id)
    .single();
  if (error) throw error;
  return data;
}

/**
 * Utilidad: agrupa por YYYY-MM (usa created_at si no hay active_at).
 */
export function groupPlansByMonth(plans) {
  const fmt = (d) => {
    const dt = new Date(d);
    const y = dt.getFullYear();
    const m = String(dt.getMonth() + 1).padStart(2, "0");
    return `${y}-${m}`;
  };
  return plans.reduce((acc, p) => {
    const key = p.active_at ? fmt(p.active_at) : fmt(p.created_at);
    acc[key] = acc[key] || [];
    acc[key].push(p);
    return acc;
  }, {});
}

export async function fetchPlansServerSide() {
  // Invoca la Edge Function list-plans (no requiere sesión en esta iteración)
  const { data, error } = await supabase.functions.invoke("list-plans", {
    body: {},
  });
  if (error) {
    // intenta sacar más info si viene del SDK
    let status, bodyText;
    try {
      status = error?.context?.response?.status;
      bodyText = await error?.context?.response?.text?.();
    } catch (_) {}
    throw new Error(bodyText || error.message || "Error list-plans");
  }
  if (!data?.ok) throw new Error(data?.error || "list-plans devolvió ok=false");
  return { active: data.active || null, inactive: data.inactive || [] };
}
