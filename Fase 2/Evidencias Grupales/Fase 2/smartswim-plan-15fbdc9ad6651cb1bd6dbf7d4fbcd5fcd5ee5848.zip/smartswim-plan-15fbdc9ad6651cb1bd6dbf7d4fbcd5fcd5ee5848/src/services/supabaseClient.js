// src/services/supabaseClient.js
import "react-native-url-polyfill/auto";
import { createClient } from "@supabase/supabase-js";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Constants from "expo-constants";

// Lee desde process.env (SDKs nuevos) o desde app.json (Constants.extra)
const extra = Constants?.expoConfig?.extra ?? Constants?.manifest?.extra ?? {};

const supabaseUrl = (
  process.env.EXPO_PUBLIC_SUPABASE_URL ||
  extra.EXPO_PUBLIC_SUPABASE_URL ||
  ""
).trim();

const supabaseAnonKey = (
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ||
  extra.EXPO_PUBLIC_SUPABASE_ANON_KEY ||
  ""
).trim();

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn(
    "[Supabase] Falta configuración. url?",
    !!supabaseUrl,
    "anon?",
    !!supabaseAnonKey,
    "\nextra keys disponibles:",
    Object.keys(extra || {})
  );
  // Lanzar error explícito ayuda a detectar el problema en tiempo de ejecución
  throw new Error(
    "Supabase URL/Anon Key no definidas. Revisa app.json -> expo.extra"
  );
}

export const SUPABASE_URL = supabaseUrl;
export const SUPABASE_ANON = supabaseAnonKey;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Log de verificación (aparece en la terminal de Expo / debugger)
console.log("[Supabase] url:", supabaseUrl, "anon?", !!supabaseAnonKey);

export default supabase;
