import React from "react";
import { ScrollView, View, Text } from "react-native";

/**
 * Muestra un plan ya guardado (planRow.plan), con el mismo formato de PlanScreen pero sin botón Guardar.
 * Recibe route.params.planRow (fila de training_plans).
 */
export default function PlanDetailScreen({ route }) {
  const planRow = route?.params?.planRow;
  const plan = planRow?.plan || {};
  const weeklyBlocks = plan?.weeklyBlocks ?? [];
  const overview = plan?.overview ?? planRow?.overview ?? "Plan";

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: "#f7f7f7" }}
      contentContainerStyle={{ padding: 16 }}
    >
      <Text style={{ fontSize: 22, fontWeight: "800", marginBottom: 10 }}>
        {planRow?.title || "Detalle del plan"}
      </Text>
      <Text style={{ marginBottom: 16, color: "#333" }}>{overview}</Text>

      {weeklyBlocks.map((w) => (
        <View
          key={w.week}
          style={{
            backgroundColor: "white",
            borderRadius: 14,
            padding: 14,
            marginBottom: 12,
            borderWidth: 1,
            borderColor: "#eee",
          }}
        >
          <Text style={{ fontSize: 18, fontWeight: "700", marginBottom: 6 }}>
            Semana {w.week} {w.theme ? `· ${w.theme}` : ""}
          </Text>

          {(w.sessions ?? []).map((s, i) => (
            <View
              key={i}
              style={{
                borderTopWidth: i === 0 ? 0 : 1,
                borderTopColor: "#eee",
                paddingTop: i === 0 ? 0 : 8,
                marginTop: i === 0 ? 0 : 8,
              }}
            >
              <Text style={{ fontWeight: "600" }}>
                {s.day} · {s.focus} ({s.totalMinutes} min)
                {s.intensity ? ` · ${s.intensity}` : ""}
              </Text>
              {s.warmup ? (
                <Text style={{ color: "#333" }}>Calentamiento: {s.warmup}</Text>
              ) : null}
              {s.mainSet ? (
                <Text style={{ color: "#333" }}>
                  Serie principal: {s.mainSet}
                </Text>
              ) : null}
              {s.cooldown ? (
                <Text style={{ color: "#333" }}>
                  Vuelta a la calma: {s.cooldown}
                </Text>
              ) : null}
              {s.metrics?.distanceMeters ? (
                <Text style={{ color: "#333" }}>
                  Distancia: {s.metrics.distanceMeters} m
                </Text>
              ) : null}
              {s.metrics?.targetPace100m ? (
                <Text style={{ color: "#333" }}>
                  Ritmo objetivo 100m: {s.metrics.targetPace100m}
                </Text>
              ) : null}
              {s.notes ? (
                <Text style={{ color: "#666" }}>Notas: {s.notes}</Text>
              ) : null}
            </View>
          ))}
        </View>
      ))}
    </ScrollView>
  );
}
