import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  ScrollView,
  Text,
  Pressable,
  ActivityIndicator,
  Alert,
} from "react-native";
import { supabase } from "../services/supabaseClient";
import {
  getActivePlan,
  listInactivePlans,
  groupPlansByMonth,
  fetchPlansServerSide,
} from "../services/planService";

// (Opcional DEV) autologin temporal si no tienes login implementado
const AUTOLOGIN_EMAIL = ""; // "dev@example.com"
const AUTOLOGIN_PASSWORD = ""; // "supersecreta"
async function ensureSessionIfNeeded() {
  const { data } = await supabase.auth.getSession();
  if (data?.session) return;
  if (!AUTOLOGIN_EMAIL || !AUTOLOGIN_PASSWORD) return;
  await supabase.auth.signInWithPassword({
    email: AUTOLOGIN_EMAIL,
    password: AUTOLOGIN_PASSWORD,
  });
}

// ---- Componentes auxiliares ----
function Card({ children }) {
  return (
    <View
      style={{
        backgroundColor: "white",
        borderRadius: 14,
        padding: 14,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: "#eee",
      }}
    >
      {children}
    </View>
  );
}

function PlanHeader({ plan, onOpen }) {
  const weeks =
    plan?.weeks_count ?? plan?.plan?.meta?.planDurationWeeks ?? null;
  const dperw = plan?.days_per_week ?? plan?.plan?.meta?.daysPerWeek ?? null;
  const avgMin =
    plan?.avg_minutes_session ?? plan?.plan?.meta?.avgMinutesSession ?? null;
  const date = plan?.active_at || plan?.created_at;

  return (
    <View>
      <Text style={{ fontSize: 16, fontWeight: "700" }}>
        {plan?.title || "Plan sin título"}
      </Text>
      <Text style={{ color: "#444", marginTop: 4 }}>
        {plan?.overview || "Sin descripción"}
      </Text>
      <Text style={{ color: "#666", marginTop: 6 }}>
        {weeks ? `${weeks} semanas · ` : ""}
        {dperw ? `${dperw} días/sem · ` : ""}
        {avgMin ? `${avgMin} min/sesión · ` : ""}
        {date ? new Date(date).toLocaleString() : ""}
      </Text>
      <Pressable
        onPress={onOpen}
        style={{
          marginTop: 10,
          backgroundColor: "#111827",
          paddingVertical: 10,
          borderRadius: 10,
          alignItems: "center",
        }}
      >
        <Text style={{ color: "white", fontWeight: "700" }}>Ver plan</Text>
      </Pressable>
    </View>
  );
}

// ---- Pantalla principal ----
export default function ViewScreen({ navigation, route }) {
  const highlightId = route?.params?.highlightId || null;
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState(null);
  const [inactive, setInactive] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState(null);

  async function load() {
    try {
      setLoading(true);
      // 👇 ya no dependemos de sesión del cliente
      const { active: a, inactive: list } = await fetchPlansServerSide();
      setActive(a);
      setInactive(list);

      const months = Object.keys(groupPlansByMonth(list)).sort().reverse();
      setSelectedMonth(months[0] || null);
    } catch (e) {
      Alert.alert("Error cargando planes", String(e?.message ?? e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const grouped = useMemo(() => groupPlansByMonth(inactive), [inactive]);
  const monthsDesc = useMemo(
    () => Object.keys(grouped).sort().reverse(),
    [grouped]
  );
  const currentMonthPlans = selectedMonth
    ? grouped[selectedMonth] || []
    : inactive;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: "#f7f7f7" }}
      contentContainerStyle={{ padding: 16 }}
    >
      <Text style={{ fontSize: 22, fontWeight: "800", marginBottom: 10 }}>
        Tus planes
      </Text>

      {loading ? (
        <ActivityIndicator />
      ) : (
        <>
          {/* ACTIVO */}
          <Text style={{ fontSize: 18, fontWeight: "700", marginBottom: 6 }}>
            Plan activo
          </Text>
          {active ? (
            <Card>
              <PlanHeader
                plan={active}
                onOpen={() =>
                  navigation.navigate("PlanDetail", { planRow: active })
                }
              />
              {Array.isArray(active?.plan?.weeklyBlocks) &&
                active.plan.weeklyBlocks.length > 0 && (
                  <View style={{ marginTop: 10 }}>
                    <Text style={{ fontWeight: "600", marginBottom: 6 }}>
                      Semanas:
                    </Text>
                    {active.plan.weeklyBlocks.map((w, i) => (
                      <Text key={i} style={{ color: "#444" }}>
                        • Semana {w.week}: {w.sessions?.length ?? 0} sesiones
                      </Text>
                    ))}
                  </View>
                )}
            </Card>
          ) : (
            <Card>
              <Text style={{ color: "#666" }}>No tienes un plan activo.</Text>
            </Card>
          )}

          {/* HISTORIAL */}
          <Text
            style={{
              fontSize: 18,
              fontWeight: "700",
              marginTop: 8,
              marginBottom: 6,
            }}
          >
            Historial (inactivos)
          </Text>

          {/* Filtro por mes */}
          {monthsDesc.length > 0 && (
            <View
              style={{
                flexDirection: "row",
                flexWrap: "wrap",
                marginBottom: 8,
              }}
            >
              {monthsDesc.map((m) => {
                const selected = selectedMonth === m;
                return (
                  <Pressable
                    key={m}
                    onPress={() =>
                      setSelectedMonth((prev) => (prev === m ? null : m))
                    }
                    style={{
                      paddingVertical: 6,
                      paddingHorizontal: 10,
                      borderRadius: 999,
                      borderWidth: 1,
                      borderColor: selected ? "#0066ff" : "#ccc",
                      backgroundColor: selected ? "#e8f0ff" : "transparent",
                      marginRight: 8,
                      marginBottom: 8,
                    }}
                  >
                    <Text style={{ color: selected ? "#004cc9" : "#333" }}>
                      {m}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          )}

          {currentMonthPlans.length === 0 ? (
            <Card>
              <Text style={{ color: "#666" }}>
                Sin planes inactivos{" "}
                {selectedMonth ? `en ${selectedMonth}` : ""}.
              </Text>
            </Card>
          ) : (
            currentMonthPlans.map((p) => (
              <Card key={p.id}>
                <PlanHeader
                  plan={p}
                  onOpen={() =>
                    navigation.navigate("PlanDetail", { planRow: p })
                  }
                />
              </Card>
            ))
          )}
        </>
      )}
    </ScrollView>
  );
}
