import { View, Pressable, Text } from "react-native";

/** Chips multiselección
 * options: [{ key: "mon", label: "Lunes" }, ...]
 * selectedKeys: ["mon","wed"]
 * onChange(nextKeys): callback con el array actualizado
 */
export default function SegmentedMulti({
  options = [],
  selectedKeys = [],
  onChange,
}) {
  return (
    <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
      {options.map((opt) => {
        const key = opt.key ?? String(opt);
        const label = opt.label ?? String(opt);
        const active = selectedKeys.includes(key);

        const toggle = () => {
          const next = active
            ? selectedKeys.filter((k) => k !== key)
            : [...selectedKeys, key];
          onChange(next);
        };

        return (
          <Pressable
            key={key}
            onPress={toggle}
            style={{
              paddingVertical: 8,
              paddingHorizontal: 12,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: active ? "#0066ff" : "#ccc",
              backgroundColor: active ? "#e8f0ff" : "transparent",
              marginRight: 8,
              marginBottom: 8,
            }}
          >
            <Text style={{ color: active ? "#004cc9" : "#333" }}>{label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}
