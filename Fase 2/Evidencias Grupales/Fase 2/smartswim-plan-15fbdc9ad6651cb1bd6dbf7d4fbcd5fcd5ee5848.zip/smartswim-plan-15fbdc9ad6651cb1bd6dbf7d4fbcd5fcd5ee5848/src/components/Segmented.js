import { View, Pressable, Text } from "react-native";

export default function Segmented({ options = [], value, onChange }) {
  return (
    <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
      {options.map((opt) => {
        const active = value === opt;
        return (
          <Pressable
            key={opt}
            onPress={() => onChange(opt)}
            style={{
              paddingVertical: 8,
              paddingHorizontal: 12,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: active ? "#0066ff" : "#ccc",
              backgroundColor: active ? "#e8f0ff" : "transparent",
              marginRight: 8,
              marginBottom: 8,
            }}
          >
            <Text style={{ color: active ? "#004cc9" : "#333" }}>{opt}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}
