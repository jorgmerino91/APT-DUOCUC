import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import SurveyScreen from "./src/screens/SurveyScreen";
import PlanScreen from "./src/screens/PlanScreen";
import ViewScreen from "./src/screens/ViewScreen"; // ✅ NUEVA pantalla (lista Activo + Historial)
import PlanDetailScreen from "./src/screens/PlanDetailScreen"; // ✅ Detalle de un plan guardado

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Encuesta">
        <Stack.Screen name="Encuesta" component={SurveyScreen} />
        <Stack.Screen
          name="Plan"
          component={PlanScreen}
          options={{ title: "Plan generado" }}
        />
        <Stack.Screen
          name="View"
          component={ViewScreen}
          options={{ title: "Mis planes" }}
        />
        <Stack.Screen
          name="PlanDetail"
          component={PlanDetailScreen}
          options={{ title: "Detalle del plan" }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
