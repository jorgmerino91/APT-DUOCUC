export async function generatePlanMock({ survey }) {
  // ---- Derivados desde la encuesta ----
  const daysPerWeek = (survey.selectedDays ?? []).length;
  const hoursArray = Object.values(survey.poolHoursPerDay ?? {});
  const totalHours = hoursArray.reduce((acc, h) => acc + Number(h || 0), 0);
  // promedio de minutos por sesión (si no hay datos, usa 60 por defecto)
  const avgMinutesSession =
    daysPerWeek > 0 ? Math.round((totalHours / daysPerWeek) * 60) : 60;

  // ---- Sesión tipo (usando esos minutos) ----
  const sessionTemplate = (dayLabel, focus, mainSet, distanceMeters) => ({
    day: dayLabel,
    focus,
    totalMinutes: avgMinutesSession, // <-- ahora rellena el paréntesis (min)
    intensity:
      focus === "Aeróbico"
        ? "Z2"
        : focus === "Velocidad"
        ? "Z3/Z4"
        : "RPE 5/10",
    warmup: "200–300m suaves + técnica",
    mainSet,
    cooldown: "200m suaves",
    metrics: { distanceMeters },
  });

  return {
    meta: {
      planDurationWeeks: 4,
      model: "mock",
      createdAt: new Date().toISOString(),
      athleteProfile: survey,
      daysPerWeek,
      avgMinutesSession,
    },
    overview: `Plan para ${daysPerWeek} días/semana, ${avgMinutesSession} min/sesión. Objetivo: ${
      survey.goals || "—"
    }.`,
    weeklyBlocks: Array.from({ length: 4 }).map((_, idx) => ({
      week: idx + 1,
      theme:
        idx === 0 ? "Adaptación" : idx === 3 ? "Consolidación" : "Progresión",
      objectives: ["Mejorar técnica", "Aumentar volumen gradualmente"],
      sessions: [
        sessionTemplate("Día 1", "Técnica", "8x50m drill/pull", 1800),
        sessionTemplate("Día 2", "Aeróbico", "6x200m c/20''", 2200),
        sessionTemplate("Día 3", "Velocidad", "12x50m rápidos", 1800),
      ],
    })),
  };
}
