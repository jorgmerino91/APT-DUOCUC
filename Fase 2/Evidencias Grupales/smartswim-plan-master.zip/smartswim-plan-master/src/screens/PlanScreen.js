import { View, ScrollView, Text, Pressable, Alert } from "react-native";

export default function PlanScreen({ route }) {
  const { plan, survey } = route.params ?? {};
  const weeklyBlocks = plan?.weeklyBlocks ?? [];
  const overview = plan?.overview ?? "Plan generado (mock).";

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: "#f7f7f7" }}
      contentContainerStyle={{ padding: 16 }}
    >
      <Text style={{ fontSize: 22, fontWeight: "800", marginBottom: 10 }}>
        Tu plan de entrenamiento
      </Text>
      <Text style={{ marginBottom: 16, color: "#333" }}>{overview}</Text>

      {weeklyBlocks.map((w) => (
        <View
          key={w.week}
          style={{
            backgroundColor: "white",
            borderRadius: 14,
            padding: 14,
            marginBottom: 12,
            borderWidth: 1,
            borderColor: "#eee",
          }}
        >
          <Text style={{ fontSize: 18, fontWeight: "700", marginBottom: 6 }}>
            Semana {w.week}
            {w.theme ? ` · ${w.theme}` : ""}
          </Text>
          {w.objectives?.length ? (
            <View style={{ marginBottom: 8 }}>
              <Text style={{ fontWeight: "600" }}>Objetivos:</Text>
              {w.objectives.map((o, i) => (
                <Text key={i} style={{ color: "#444" }}>
                  • {o}
                </Text>
              ))}
            </View>
          ) : null}

          {(w.sessions ?? []).map((s, i) => (
            <View
              key={i}
              style={{
                borderTopWidth: i === 0 ? 0 : 1,
                borderTopColor: "#eee",
                paddingTop: i === 0 ? 0 : 8,
                marginTop: i === 0 ? 0 : 8,
              }}
            >
              <Text style={{ fontWeight: "600" }}>
                {s.day} · {s.focus} ({s.totalMinutes} min)
                {s.intensity ? ` · ${s.intensity}` : ""}
              </Text>
              {s.warmup ? (
                <Text style={{ color: "#333" }}>Calentamiento: {s.warmup}</Text>
              ) : null}
              {s.mainSet ? (
                <Text style={{ color: "#333" }}>
                  Serie principal: {s.mainSet}
                </Text>
              ) : null}
              {s.cooldown ? (
                <Text style={{ color: "#333" }}>
                  Vuelta a la calma: {s.cooldown}
                </Text>
              ) : null}
              {s.metrics?.distanceMeters ? (
                <Text style={{ color: "#333" }}>
                  Distancia: {s.metrics.distanceMeters} m
                </Text>
              ) : null}
              {s.metrics?.targetPace100m ? (
                <Text style={{ color: "#333" }}>
                  Ritmo objetivo 100m: {s.metrics.targetPace100m}
                </Text>
              ) : null}
              {s.notes ? (
                <Text style={{ color: "#666" }}>Notas: {s.notes}</Text>
              ) : null}
            </View>
          ))}
        </View>
      ))}
    </ScrollView>
  );
}
