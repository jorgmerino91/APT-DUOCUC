import { useState } from "react";
import {
  ScrollView,
  Text,
  Pressable,
  Alert,
  ActivityIndicator,
} from "react-native";
import Field from "../components/Field";
import Segmented from "../components/Segmented";
import SegmentedMulti from "../components/SegmentedMulti";
import { generatePlanMock } from "../services/planService";

const EXPERIENCE_OPTS = [
  "no sé nadar",
  "recreativo",
  "básico",
  "intermedio",
  "deportivo",
];

const DAYS = [
  { key: "mon", label: "Lunes" },
  { key: "tue", label: "Martes" },
  { key: "wed", label: "Miércoles" },
  { key: "thu", label: "Jueves" },
  { key: "fri", label: "Viernes" },
  { key: "sat", label: "Sábado" },
  { key: "sun", label: "Domingo" },
];

export default function SurveyScreen({ navigation }) {
  // Datos básicos
  const [age, setAge] = useState("");
  const [sex, setSex] = useState("masculino"); // masculino | femenino
  const [weightKg, setWeightKg] = useState(""); // kg
  const [heightM, setHeightM] = useState(""); // metros
  const [experience, setExperience] = useState("intermedio");
  const [goals, setGoals] = useState("");
  const [loading, setLoading] = useState(false);

  // Días seleccionados y horas por día (solo para seleccionados)
  const [selectedDays, setSelectedDays] = useState([]); // ["mon","wed", ...]
  const [poolHours, setPoolHours] = useState({}); // { mon: "1.5", wed: "2", ... }
  const setDayHours = (k, v) => setPoolHours((prev) => ({ ...prev, [k]: v }));

  function validate() {
    if (!age) return "Falta la edad.";
    if (!weightKg) return "Falta el peso (kg).";
    if (!heightM) return "Falta la altura (m).";
    if (selectedDays.length === 0)
      return "Selecciona al menos un día de piscina.";
    // valida horas de cada día seleccionado
    for (const k of selectedDays) {
      const n = Number(poolHours[k] || 0);
      if (Number.isNaN(n) || n < 0)
        return "Revisa las horas de los días seleccionados.";
    }
    return null;
  }

  async function onContinue() {
    const problem = validate();
    if (problem) {
      Alert.alert("Formulario incompleto", problem);
      return;
    }

    const poolHoursPerDay = Object.fromEntries(
      selectedDays.map((k) => [k, Number(poolHours[k] || 0)])
    );

    const survey = {
      age: Number(age || 0),
      sex,
      weightKg: Number(weightKg || 0),
      heightM: Number(heightM || 0),
      experience,
      goals,
      selectedDays,
      poolHoursPerDay, // solo días seleccionados
    };

    try {
      setLoading(true);
      const plan = await generatePlanMock({ survey });
      navigation.navigate("Plan", { plan, survey });
    } catch (e) {
      Alert.alert("Error", String(e?.message ?? e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: "#f7f7f7" }}
      contentContainerStyle={{ padding: 16 }}
    >
      <Text style={{ fontSize: 22, fontWeight: "700", marginBottom: 12 }}>
        Cuestionario
      </Text>

      <Field
        label="Edad"
        value={age}
        onChangeText={setAge}
        keyboardType="number-pad"
      />

      <Text style={{ marginTop: 8, marginBottom: 6, fontWeight: "600" }}>
        Sexo
      </Text>
      <Segmented
        options={["masculino", "femenino"]}
        value={sex}
        onChange={setSex}
      />

      <Field
        label="Peso (kg)"
        value={weightKg}
        onChangeText={setWeightKg}
        keyboardType="decimal-pad"
        placeholder="Ej: 78.5"
      />
      <Field
        label="Altura (m)"
        value={heightM}
        onChangeText={setHeightM}
        keyboardType="decimal-pad"
        placeholder="Ej: 1.73"
      />

      <Text style={{ marginTop: 8, marginBottom: 6, fontWeight: "600" }}>
        Nivel de experiencia en natación
      </Text>
      <Segmented
        options={EXPERIENCE_OPTS}
        value={experience}
        onChange={setExperience}
      />

      <Text style={{ marginTop: 12, marginBottom: 6, fontWeight: "600" }}>
        ¿Qué días puedes nadar?
      </Text>
      <SegmentedMulti
        options={DAYS}
        selectedKeys={selectedDays}
        onChange={setSelectedDays}
      />

      {selectedDays.length > 0 && (
        <>
          <Text style={{ marginTop: 12, marginBottom: 6, fontWeight: "600" }}>
            Horas por cada día seleccionado
          </Text>
          {selectedDays.map((k) => {
            const label = DAYS.find((d) => d.key === k)?.label ?? k;
            return (
              <Field
                key={k}
                label={`${label} (h)`}
                value={poolHours[k] ?? ""}
                onChangeText={(t) => setDayHours(k, t)}
                keyboardType="decimal-pad"
                placeholder="0"
              />
            );
          })}
        </>
      )}

      <Field
        label="Objetivos de entrenamiento"
        value={goals}
        onChangeText={setGoals}
        multiline
        placeholder='Ej: "mejorar resistencia para 1500m", "bajar de 2:00 en 100m"'
      />

      <Pressable
        onPress={onContinue}
        disabled={loading}
        style={{
          marginTop: 18,
          backgroundColor: "#0a7",
          paddingVertical: 14,
          borderRadius: 12,
          alignItems: "center",
          opacity: loading ? 0.6 : 1,
        }}
      >
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={{ color: "white", fontSize: 16, fontWeight: "700" }}>
            Generar plan (mock)
          </Text>
        )}
      </Pressable>
    </ScrollView>
  );
}
