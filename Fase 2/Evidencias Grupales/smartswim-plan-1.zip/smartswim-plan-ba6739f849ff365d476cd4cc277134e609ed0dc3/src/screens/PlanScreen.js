import React, { useState } from "react";
import {
  View,
  ScrollView,
  Text,
  Pressable,
  Alert,
  ActivityIndicator,
} from "react-native";
import { supabase } from "../services/supabaseClient";
import { savePlan as savePlanClient } from "../services/planService";

/**
 * CONFIG DE GUARDADO
 * - USE_EDGE_SAVE = true  -> usa Edge Function "save-plan" (recomendado, no requiere sesión en el cliente)
 * - USE_EDGE_SAVE = false -> guarda directo desde el cliente (requiere sesión; se puede usar autologin DEV)
 */
const USE_EDGE_SAVE = true;

/**
 * (SOLO DEV) Autologin para el modo cliente.
 * ⚠️ No dejes credenciales hardcodeadas en producción.
 */
const AUTOLOGIN_EMAIL = ""; // ej. "dev@example.com"
const AUTOLOGIN_PASSWORD = ""; // ej. "supersecreta"

/**
 * (SOLO DEV) user_id para enviar a la Edge Function.
 * Si lo dejas vacío, la función intentará usar DEMO_USER_ID (secret) o el sub del JWT si hay sesión.
 * Pon aquí el UUID de un usuario en Auth > Users para forzar el guardado bajo ese usuario.
 */
const DEV_USER_ID = ""; // ej. "5f14c3a4-0a3f-4f0b-9d0c-123456789abc"

async function ensureSessionWithAutoLogin() {
  const { data: sData, error: sErr } = await supabase.auth.getSession();
  if (sErr) console.warn("[ensureSession] getSession error:", sErr);
  if (sData?.session) return sData.session;

  if (!AUTOLOGIN_EMAIL || !AUTOLOGIN_PASSWORD) {
    throw new Error(
      "No hay sesión y no hay credenciales de autologin configuradas."
    );
  }

  console.log("[ensureSession] intentando autologin…");
  const { error: signErr } = await supabase.auth.signInWithPassword({
    email: AUTOLOGIN_EMAIL,
    password: AUTOLOGIN_PASSWORD,
  });
  if (signErr) throw signErr;

  const { data: sData2 } = await supabase.auth.getSession();
  console.log("[ensureSession] sesión creada?", !!sData2?.session);
  return sData2?.session ?? null;
}

export default function PlanScreen({ route }) {
  const { plan, survey } = route.params ?? {};
  const weeklyBlocks = plan?.weeklyBlocks ?? [];
  const overview =
    plan?.overview ??
    "Plan generado. Revisa sesiones y guarda si todo se ve bien.";

  const [saving, setSaving] = useState(false);

  // ---------- GUARDADO ----------
  // A) Guardar llamando a Edge Function "save-plan" (recomendado)
  const saveViaEdge = async () => {
    console.log("[PlanScreen] saveViaEdge start");

    const body = {
      plan,
      survey,
      title: `Plan ${survey?.weeks || 4} semanas`,
      user_change: null,
      ...(DEV_USER_ID ? { user_id: DEV_USER_ID } : {}), // 👈 enviar user_id si lo configuraste
    };

    const { data, error } = await supabase.functions.invoke("save-plan", {
      body,
    });

    console.log("[PlanScreen] saveViaEdge response:", {
      ok: data?.ok,
      id: data?.id,
      error,
    });

    if (error) throw error;
    if (!data?.ok)
      throw new Error(data?.error || "save-plan devolvió ok=false");
    return data?.id;
  };

  // B) Guardar directo desde el cliente (requiere sesión)
  const saveViaClient = async () => {
    console.log("[PlanScreen] saveViaClient start");
    await ensureSessionWithAutoLogin();
    const row = await savePlanClient({
      plan,
      survey,
      title: `Plan ${survey?.weeks || 4} semanas`,
      // userChange: "…"
    });
    return row?.id;
  };

  const onSave = async () => {
    try {
      setSaving(true);
      console.log("[PlanScreen] onSave click", {
        weeks: survey?.weeks,
        sessionsW1: plan?.weeklyBlocks?.[0]?.sessions?.length,
      });

      const savedId = USE_EDGE_SAVE
        ? await saveViaEdge()
        : await saveViaClient();

      console.log("[PlanScreen] saved id:", savedId);
      Alert.alert("Guardado", "Tu plan fue guardado correctamente.");
    } catch (e) {
      // Extrae info útil si viene de una Edge Function (FunctionsHttpError)
      let status, bodyText;
      try {
        status = e?.context?.response?.status;
        bodyText = await e?.context?.response?.text?.();
      } catch (_) {}
      console.warn(
        "[PlanScreen] save error:",
        e,
        "status:",
        status,
        "body:",
        bodyText
      );
      Alert.alert("Error", bodyText || String(e?.message ?? e));
    } finally {
      setSaving(false);
    }
  };

  // ---------- UI ----------
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: "#f7f7f7" }}
      contentContainerStyle={{ padding: 16 }}
    >
      <Text style={{ fontSize: 22, fontWeight: "800", marginBottom: 10 }}>
        Tu plan de entrenamiento
      </Text>
      <Text style={{ marginBottom: 16, color: "#333" }}>{overview}</Text>

      {weeklyBlocks.map((w) => (
        <View
          key={w.week}
          style={{
            backgroundColor: "white",
            borderRadius: 14,
            padding: 14,
            marginBottom: 12,
            borderWidth: 1,
            borderColor: "#eee",
          }}
        >
          <Text style={{ fontSize: 18, fontWeight: "700", marginBottom: 6 }}>
            Semana {w.week}
            {w.theme ? ` · ${w.theme}` : ""}
          </Text>

          {w.objectives?.length ? (
            <View style={{ marginBottom: 8 }}>
              <Text style={{ fontWeight: "600" }}>Objetivos:</Text>
              {w.objectives.map((o, i) => (
                <Text key={i} style={{ color: "#444" }}>
                  • {o}
                </Text>
              ))}
            </View>
          ) : null}

          {(w.sessions ?? []).map((s, i) => (
            <View
              key={i}
              style={{
                borderTopWidth: i === 0 ? 0 : 1,
                borderTopColor: "#eee",
                paddingTop: i === 0 ? 0 : 8,
                marginTop: i === 0 ? 0 : 8,
              }}
            >
              <Text style={{ fontWeight: "600" }}>
                {s.day} · {s.focus} ({s.totalMinutes} min)
                {s.intensity ? ` · ${s.intensity}` : ""}
              </Text>
              {s.warmup ? (
                <Text style={{ color: "#333" }}>Calentamiento: {s.warmup}</Text>
              ) : null}
              {s.mainSet ? (
                <Text style={{ color: "#333" }}>
                  Serie principal: {s.mainSet}
                </Text>
              ) : null}
              {s.cooldown ? (
                <Text style={{ color: "#333" }}>
                  Vuelta a la calma: {s.cooldown}
                </Text>
              ) : null}
              {s.metrics?.distanceMeters ? (
                <Text style={{ color: "#333" }}>
                  Distancia: {s.metrics.distanceMeters} m
                </Text>
              ) : null}
              {s.metrics?.targetPace100m ? (
                <Text style={{ color: "#333" }}>
                  Ritmo objetivo 100m: {s.metrics.targetPace100m}
                </Text>
              ) : null}
              {s.notes ? (
                <Text style={{ color: "#666" }}>Notas: {s.notes}</Text>
              ) : null}
            </View>
          ))}
        </View>
      ))}

      {/* Botón Guardar */}
      <Pressable
        onPress={onSave}
        disabled={saving}
        style={{
          marginTop: 12,
          backgroundColor: "#111827",
          paddingVertical: 14,
          borderRadius: 12,
          alignItems: "center",
          opacity: saving ? 0.6 : 1,
        }}
      >
        {saving ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={{ color: "white", fontSize: 16, fontWeight: "700" }}>
            Guardar plan
          </Text>
        )}
      </Pressable>
    </ScrollView>
  );
}
