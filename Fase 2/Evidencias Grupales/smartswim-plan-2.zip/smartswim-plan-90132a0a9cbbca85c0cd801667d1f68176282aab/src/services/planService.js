// src/services/planService.js
import { supabase, SUPABASE_URL, SUPABASE_ANON } from "./supabaseClient";

async function invokeWithSdk(survey) {
  // ¡sin headers! el SDK los agrega
  const { data, error } = await supabase.functions.invoke("generate-plan", {
    body: { survey },
  });

  if (error) {
    // intenta leer status/text si tu SDK lo expone
    let status, bodyText;
    try {
      status = error?.context?.response?.status;
      bodyText = await error?.context?.response?.text?.();
    } catch (_) {}
    console.warn("[Edge invoke][SDK] status:", status, "body:", bodyText);
    throw new Error(bodyText || error.message || "Edge Function error (SDK)");
  }

  if (!data?.ok || !data?.plan)
    throw new Error("Respuesta inválida del servidor (SDK)");
  return data.plan;
}

async function invokeWithFetch(survey) {
  const endpoint = `${SUPABASE_URL}/functions/v1/generate-plan`;
  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${SUPABASE_ANON}`,
      apikey: SUPABASE_ANON,
    },
    body: JSON.stringify({ survey }),
  });

  const data = await res.json().catch(() => ({}));
  console.log("[Edge invoke][fetch] http:", res.status, "ok:", data?.ok);

  if (!res.ok) throw new Error(data?.error || `HTTP ${res.status} (fetch)`);
  if (!data?.ok || !data?.plan)
    throw new Error("Respuesta inválida del servidor (fetch)");
  return data.plan;
}

export async function generatePlan({ survey }) {
  if (!survey) throw new Error("Falta el objeto survey");

  console.log("[planService] supabase OK?", typeof supabase === "object");
  console.log(
    "[planService] has functions.invoke?",
    typeof supabase?.functions?.invoke
  );

  // 1) intenta SDK sin headers
  try {
    return await invokeWithSdk(survey);
  } catch (e) {
    console.warn(
      "[SDK invoke falló, probando fetch]:",
      String(e?.message ?? e)
    );
    // 2) fallback por fetch directo
    return await invokeWithFetch(survey);
  }
}

export default { generatePlan };
